import "dotenv/config";
import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  Interaction,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
} from "discord.js";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";

const BOT_DISPLAY_NAME = "𝑺𝑨𝑷 𝑻𝑬𝑨𝑴";
const API_BASE = process.env.SCRIPTBLOX_API_BASE ?? "https://scriptblox.com";
const RESULTS_PER_PAGE = Math.min(
  20,
  Math.max(1, Number.parseInt(process.env.SEARCH_RESULTS_PER_PAGE ?? "5", 10) || 5),
);
const STATE_FILE = join(process.cwd(), "data", "channels.json");

type ScriptResult = {
  _id?: string;
  title?: string;
  slug?: string;
  script?: string;
  image?: string;
  verified?: boolean;
  key?: boolean;
  isUniversal?: boolean;
  isPatched?: boolean;
  views?: number;
  game?: {
    name?: string;
    imageUrl?: string;
  };
};

type ChannelState = Record<string, { guildId: string; enabled: boolean }>;
type CopyableScript = { title: string; code: string };

const copyableScripts = new Map<string, CopyableScript>();

const command = new SlashCommandBuilder()
  .setName("search-scripts")
  .setNameLocalizations({ ar: "بحث-سكربتات" } as any)
  .setDescription("Enable or search public Roblox scripts")
  .setDescriptionLocalizations({
    ar: "فعّل البحث أو ابحث عن سكربتات روبلوكس عامة",
  } as any)
  .addStringOption((option) =>
    option
      .setName("map")
      .setNameLocalizations({ ar: "ماب" } as any)
      .setDescription("The Roblox map or game name")
      .setDescriptionLocalizations({ ar: "اسم الماب أو اللعبة" } as any)
      .setRequired(false)
      .setAutocomplete(false),
  );

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

async function loadChannels(): Promise<ChannelState> {
  try {
    return JSON.parse(await readFile(STATE_FILE, "utf8")) as ChannelState;
  } catch {
    return {};
  }
}

async function saveChannels(channels: ChannelState): Promise<void> {
  await mkdir(dirname(STATE_FILE), { recursive: true });
  await writeFile(STATE_FILE, JSON.stringify(channels, null, 2), "utf8");
}

function isModerator(interaction: Interaction): boolean {
  return (
    interaction.isChatInputCommand() &&
    Boolean(
      interaction.memberPermissions?.has(
        PermissionsBitField.Flags.ManageGuild,
      ),
    )
  );
}

function trimScript(script: string): string {
  return script.replace(/\r\n/g, "\n").trim();
}

function safeText(value: unknown, fallback: string): string {
  const text = typeof value === "string" ? value.trim() : "";
  return text || fallback;
}

function scriptUrl(script: ScriptResult): string | null {
  return script.slug ? `https://scriptblox.com/script/${script.slug}` : null;
}

async function searchScripts(query: string): Promise<ScriptResult[]> {
  const url = new URL("/api/script/search", API_BASE);
  url.searchParams.set("q", query);
  url.searchParams.set("max", String(RESULTS_PER_PAGE));
  url.searchParams.set("page", "1");
  url.searchParams.set("strict", "false");
  url.searchParams.set("sortBy", "accuracy");
  url.searchParams.set("order", "desc");

  const response = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "SAP-TEAM-Discord-Bot/1.0" },
    signal: AbortSignal.timeout(12_000),
  });

  if (!response.ok) {
    throw new Error(`ScriptBlox returned HTTP ${response.status}`);
  }

  const payload = (await response.json()) as {
    result?: { scripts?: ScriptResult[] };
    message?: string;
  };

  if (payload.message) {
    throw new Error(payload.message);
  }

  return payload.result?.scripts ?? [];
}

function makeEmbed(script: ScriptResult): EmbedBuilder {
  const title = safeText(script.title, "بدون اسم");
  const game = safeText(script.game?.name, "ماب غير معروف");
  const code = trimScript(safeText(script.script, "-- لا يوجد كود متاح"));
  const url = scriptUrl(script);
  const image = script.game?.imageUrl || script.image;
  const preview = code.length > 650 ? `${code.slice(0, 647)}...` : code;

  const embed = new EmbedBuilder()
    .setColor(0x8b5cf6)
    .setTitle(title)
    .addFields(
      { name: "الماب", value: game, inline: true },
      {
        name: "السكربت",
        value: code.length > 1800 ? "اضغط زر نسخ السكربت لإظهاره" : "موجود بالأسفل",
        inline: true,
      },
      {
        name: "الكود",
        value: `\`\`\`lua\n${preview.replace(/```/g, "`​``")}\n\`\`\``,
      },
    )
    .setFooter({ text: `${BOT_DISPLAY_NAME} • اضغط نسخ السكربت لإظهاره لك` });

  if (url) embed.setURL(url);
  if (image?.startsWith("http")) embed.setThumbnail(image);
  return embed;
}

function makeCopyButton(cacheKey: string): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`copy-script:${cacheKey}`)
      .setLabel("نسخ السكربت")
      .setEmoji("📋")
      .setStyle(ButtonStyle.Primary),
  );
}

function cacheScript(script: ScriptResult): string {
  const key = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  copyableScripts.set(key, {
    title: safeText(script.title, "script"),
    code: trimScript(safeText(script.script, "-- لا يوجد كود متاح")),
  });
  setTimeout(() => copyableScripts.delete(key), 15 * 60 * 1000).unref();
  return key;
}

async function handleSearch(interaction: Interaction): Promise<void> {
  if (
    !(
      (interaction.isChatInputCommand() && interaction.commandName === "search-scripts") ||
      (interaction.isButton() && interaction.customId.startsWith("copy-script:"))
    )
  ) {
    return;
  }

  if (interaction.isButton()) {
    const key = interaction.customId.slice("copy-script:".length);
    const cached = copyableScripts.get(key);
    if (!cached) {
      await interaction.reply({
        content: "انتهت صلاحية زر النسخ. أعد البحث عن الماب.",
        ephemeral: true,
      });
      return;
    }

    if (cached.code.length <= 1800) {
      await interaction.reply({
        content: `**${cached.title}**\n\`\`\`lua\n${cached.code.replace(/```/g, "`​``")}\n\`\`\``,
        ephemeral: true,
        allowedMentions: { parse: [] },
      });
    } else {
      await interaction.reply({
        content: `هذا سكربت طويل، حملته لك كملف باسم \`${cached.title}.lua\`.`,
        files: [
          new AttachmentBuilder(Buffer.from(cached.code, "utf8"), {
            name: `${cached.title.replace(/[^a-z0-9-_]/gi, "_").slice(0, 60) || "script"}.lua`,
          }),
        ],
        ephemeral: true,
        allowedMentions: { parse: [] },
      });
    }
    return;
  }

  const map = interaction.options.getString("map")?.trim() ?? "";
  const guildId = interaction.guildId;
  const channelId = interaction.channelId;
  if (!guildId || !channelId) {
    await interaction.reply({
      content: "هذا الأمر يعمل داخل السيرفرات فقط.",
      ephemeral: true,
    });
    return;
  }

  const channels = await loadChannels();

  if (!map) {
    if (!isModerator(interaction)) {
      await interaction.reply({
        content: "فقط المشرف الذي يملك صلاحية إدارة السيرفر يستطيع التفعيل أو التعطيل.",
        ephemeral: true,
      });
      return;
    }

    const enabled = !channels[channelId]?.enabled;
    channels[channelId] = { guildId, enabled };
    await saveChannels(channels);
    await interaction.reply({
      content: enabled
        ? "✅ تم تفعيل البحث في هذا الروم فقط.\nالآن اكتب `/بحث-سكربتات` واختر اسم الماب."
        : "⛔ تم تعطيل البحث في هذا الروم.",
      ephemeral: true,
    });
    return;
  }

  if (!channels[channelId]?.enabled) {
    await interaction.reply({
      content: "البحث غير مفعّل في هذا الروم. يفعّله المشرف باستخدام الأمر بدون اسم ماب.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply();

  try {
    const script = (await searchScripts(map))[0];
    if (!script) {
      await interaction.editReply(`لم أجد سكربتات عامة مطابقة لـ **${map}**.`);
      return;
    }

    const copyKey = cacheScript(script);
    const code = trimScript(safeText(script.script, ""));
    const files: AttachmentBuilder[] = [];

    if (code.length > 1800) {
      files.push(
        new AttachmentBuilder(Buffer.from(code, "utf8"), {
          name: `${(script.slug ?? "script").replace(/[^a-z0-9-_]/gi, "_")}.lua`,
        }),
      );
    }

    await interaction.editReply({
      content: `🔎 أفضل نتيجة للماب **${map}**`,
      embeds: [makeEmbed(script)],
      components: [makeCopyButton(copyKey)],
      files,
      allowedMentions: { parse: [] },
    });
  } catch (error) {
    console.error("Script search failed:", error);
    await interaction.editReply(
      "تعذر الوصول إلى مصدر البحث الآن. جرّب مرة أخرى بعد قليل.",
    );
  }
}

client.once("ready", async (readyClient) => {
  console.log(`${BOT_DISPLAY_NAME} connected as ${readyClient.user.tag}`);

  for (const guild of readyClient.guilds.cache.values()) {
    const botMember = guild.members.me;
    if (botMember && botMember.nickname !== BOT_DISPLAY_NAME) {
      await botMember.setNickname(BOT_DISPLAY_NAME).catch((error) => {
        console.warn(`Could not set nickname in ${guild.name}:`, error.message);
      });
    }
  }

  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN!);
  const body = [command.toJSON()];

  try {
    const guildId = process.env.DISCORD_GUILD_ID;
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(readyClient.user.id, guildId), {
        body,
      });
      console.log(`Registered the single command in guild ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(readyClient.user.id), { body });
      console.log("Registered the single global command");
    }
  } catch (error) {
    console.error("Command registration failed:", error);
  }

  console.log(
    `The bot nickname is set to "${BOT_DISPLAY_NAME}" where Manage Nicknames is available.`,
  );
});

client.on("interactionCreate", (interaction) => {
  void handleSearch(interaction).catch(async (error) => {
    console.error("Interaction failed:", error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "حدث خطأ غير متوقع. جرّب مرة أخرى.",
        ephemeral: true,
      });
    }
  });
});

const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  throw new Error("DISCORD_BOT_TOKEN is missing from Replit Secrets.");
}

void client.login(token);